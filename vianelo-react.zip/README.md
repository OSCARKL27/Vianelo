# Vianelo - React + Vite starter (Landing)

## Qué hay aquí
Proyecto creado con **Vite + React** y estilos con **Bootstrap 5**.
Incluye un landing page que respeta el Brandbook de Vianelo (colores y tipografías aproximadas).

## Cómo usar (si nunca has usado Node.js)
1. Instala Node.js desde https://nodejs.org (elige LTS).
2. Abre la carpeta `vianelo-react` en VS Code.
3. Abre una terminal en la carpeta y ejecuta:
   ```bash
   npm install
   npm run dev
   ```
4. Abre `http://localhost:5173` en tu navegador.

## Estructura principal
- `index.html` - punto de entrada
- `src/` - código React
  - `components/` - componentes reutilizables (Navbar, Hero, ProductCard, Footer)
  - `pages/` - páginas (Home, Menu, About, Contact)
  - `data/menu.json` - datos de productos de ejemplo
- `public/` - assets públicos (logo, imágenes)

## Notas
- Las fuentes Collier y Darwin no están empaquetadas por licencia; he usado fuentes web similares y variables CSS para que puedas reemplazarlas por las oficiales si las consigues.
- Si quieres, puedo convertir el backend a Laravel o Node.js y añadir un panel admin para editar productos.
